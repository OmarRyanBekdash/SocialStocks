//
//  StockScreenViewController.swift
//  SocialStocksApp
//
//  Created by Omar Beckdash on 11/27/18.
//  Copyright © 2018 Omar Bekdash. All rights reserved.
//

import UIKit

class StockScreenViewController: UIViewController {
    
    var nameLabel: UILabel!
    var priceLabel: UILabel!
    var stockView: UIImageView!
    
    weak var delegate: savePrivacyDelegate?
    
    let reuseIdentifier = "stockCellReuse"
    let cellHeight: CGFloat = 80
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Personal Stocks"
        view.backgroundColor = .white
        
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.text = "Stock + name whatever it is"
        nameLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
        nameLabel.textAlignment = .left
        nameLabel.textColor = .black
        view.addSubview(nameLabel)
        
        priceLabel = UILabel()
        priceLabel.translatesAutoresizingMaskIntoConstraints = false
        priceLabel.text = "Price + $$"
        priceLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
        priceLabel.textAlignment = .left
        priceLabel.textColor = .black
        view.addSubview(priceLabel)
        
        let backButton = UIBarButtonItem()
        backButton.title = "Back"
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        stockView = UIImageView()
        stockView.translatesAutoresizingMaskIntoConstraints = false
        stockView.contentMode = .scaleAspectFit
        view.addSubview(stockView)
        
        setupConstraints()

    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            nameLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            nameLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            nameLabel.heightAnchor.constraint(equalToConstant: 40)
            ])
        
        NSLayoutConstraint.activate([
            priceLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            priceLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 20),
            priceLabel.heightAnchor.constraint(equalToConstant: 40)
            ])
        
        NSLayoutConstraint.activate([
            stockView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            stockView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stockView.heightAnchor.constraint(equalToConstant: 200),
            stockView.widthAnchor.constraint(equalToConstant: 300)
            ])
        
    }
    
    
}
