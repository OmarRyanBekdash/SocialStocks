//
//  StockTableViewCell.swift
//  SocialStocksApp
//
//  Created by Omar Beckdash on 11/27/18.
//  Copyright © 2018 Omar Bekdash. All rights reserved.
//

import UIKit

class StockTableViewCell: UITableViewCell {
    
    var nameLabel: UILabel!
    var priceLabel: UILabel!
    var stockView: UIImageView!
    
    let padding: CGFloat = 12
    let fieldHeight: CGFloat = 13
    let anImageHeight: CGFloat = 70
    let anImageWidth: CGFloat = 70
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        nameLabel = UILabel()
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.font = UIFont.systemFont(ofSize: 13)
        nameLabel.textColor = .black
        contentView.addSubview(nameLabel)
        
        priceLabel = UILabel()
        priceLabel.translatesAutoresizingMaskIntoConstraints = false
        priceLabel.font = UIFont.systemFont(ofSize: 13)
        priceLabel.textColor = .black
        contentView.addSubview(priceLabel)
        
        stockView = UIImageView()
        stockView.translatesAutoresizingMaskIntoConstraints = false
        stockView.contentMode = .scaleAspectFit
        contentView.addSubview(stockView)
        
    }
    
    override func updateConstraints() {
        NSLayoutConstraint.activate([
            nameLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            nameLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: padding),
            nameLabel.heightAnchor.constraint(equalToConstant: fieldHeight)
            ])
        
        NSLayoutConstraint.activate([
            priceLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            priceLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: padding),
            priceLabel.heightAnchor.constraint(equalToConstant: fieldHeight)
            ])
        
        NSLayoutConstraint.activate([
            stockView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: padding * -1),
            stockView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            stockView.heightAnchor.constraint(equalToConstant: anImageHeight),
            stockView.widthAnchor.constraint(equalToConstant: anImageWidth)
            ])
        
        super.updateConstraints()
    }
    
    func configure(for stock: Stock) {
        
        nameLabel.text = stock.name
        priceLabel.text = stock.price
        stockView.image = stock.image

    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
