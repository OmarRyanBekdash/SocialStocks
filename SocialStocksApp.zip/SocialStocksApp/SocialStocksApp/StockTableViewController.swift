//
//  StockTableViewController.swift
//  SocialStocksApp
//
//  Created by Omar Beckdash on 11/27/18.
//  Copyright © 2018 Omar Bekdash. All rights reserved.
//

import UIKit

class StockTableViewController: UIViewController {
    
    var songField: UITextField!
    var albumField: UITextField!
    var singerField: UITextField!
    var row: Int!
    
    weak var delegate: saveMusicInfoDelegate?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        songField = UITextField()
        songField.translatesAutoresizingMaskIntoConstraints = false
        songField.text = "Edit Song Name Here"
        songField.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        songField.textAlignment = .left
        songField.textColor = .black
        view.addSubview(songField)
        //
        albumField = UITextField()
        albumField.translatesAutoresizingMaskIntoConstraints = false
        albumField.text = "Edit Album Name Here"
        albumField.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        albumField.textAlignment = .left
        albumField.textColor = .black
        view.addSubview(albumField)
        //
        singerField = UITextField()
        singerField.translatesAutoresizingMaskIntoConstraints = false//  singerField.borderStyle = .roundedRect
        singerField.text = "Edit Singer Name Here"
        singerField.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        singerField.textAlignment = .left
        singerField.textColor = .black
        view.addSubview(singerField)
        

        let backButton = UIBarButtonItem()
        backButton.title = "Back"
        self.navigationController?.navigationBar.topItem?.backBarButtonItem = backButton
        
        setupConstraints()
        
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            songField.topAnchor.constraint(equalTo: view.topAnchor, constant: 125),
            songField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10),
            songField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            songField.heightAnchor.constraint(equalToConstant: 28)
            ])
        NSLayoutConstraint.activate([
            albumField.topAnchor.constraint(equalTo: songField.bottomAnchor, constant: 50),
            albumField.leadingAnchor.constraint(equalTo: songField.leadingAnchor),
            albumField.trailingAnchor.constraint(equalTo: songField.trailingAnchor),
            albumField.heightAnchor.constraint(equalTo: songField.heightAnchor)
            ])
        
        
        //
        NSLayoutConstraint.activate([
            singerField.topAnchor.constraint(equalTo: albumField.bottomAnchor, constant: 50),
            singerField.leadingAnchor.constraint(equalTo: albumField.leadingAnchor),
            singerField.trailingAnchor.constraint(equalTo: albumField.trailingAnchor),
            singerField.heightAnchor.constraint(equalTo: albumField.heightAnchor)
            ])
    }
    
    @objc func saveTapped() {
        //redBox.text gets the text from the Textfield
        if let text = songField.text, text != "" {
            delegate?.songChanged(newSong: text, getRow: row)
        }
        if let text = singerField.text, text != "" {
            delegate?.singerChanged(newSinger: text, getRow: row)
        }
        if let text = albumField.text, text != "" {
            delegate?.albumChanged(newAlbum: text, getRow: row)
        }
        
        self.navigationController?.popViewController(animated: true)
        
        
    }
    
    
}


