//
//  Stock.swift
//  SocialStocksApp
//
//  Created by Omar Beckdash on 11/27/18.
//  Copyright © 2018 Omar Bekdash. All rights reserved.
//

import UIKit
import Foundation

class Stock{
    var name: String
    var price: String
    var image: UIImage!
    
    init(name: String, price: String, image: UIImage!) {
        self.name = "Stock: " + name
        self.price = "Price: " + price
        self.image = image
    }
    
}
