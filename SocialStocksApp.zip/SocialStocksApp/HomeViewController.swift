//
//  HomeViewController.swift
//  SocialStocksApp
//
//  Created by Omar Beckdash on 11/27/18.
//  Copyright © 2018 Omar Bekdash. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {

    var stockView: UITableView!
    var stocks: [Stock]!
    //var notifications: UIButton!
    //var addFriend: UIButton!
    
    let reuseIdentifier = "stockCellReuse"
    let cellHeight: CGFloat = 80
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Home"
        view.backgroundColor = .white
        
        let s1 = Stock(name: "Apple", price: "idk", image: UIImage(named:"stock_graph"))
        let s2 = Stock(name: "Microsoft", price: "blah", image: UIImage(named: "stock_graph"))
        
        stocks = [s1, s2]
        
        stockView = UITableView(frame: .zero)
        stockView.translatesAutoresizingMaskIntoConstraints = false
        stockView.delegate = self
        stockView.dataSource = self
        stockView.register(StockTableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        view.addSubview(stockView)
        
        let notifications = UIBarButtonItem(title: "Notifications", style: UIBarButtonItem.Style.plain, target: self, action: #selector(notificationsButtonTapped))
        self.navigationItem.rightBarButtonItem = notifications
        
        
        let addFriend = UIBarButtonItem(title: "Add Friend", style: UIBarButtonItem.Style.plain, target: self, action: #selector(addFriendButtonTapped))
        self.navigationItem.leftBarButtonItem = addFriend
        
        /*
        notifications = UIButton()
        notifications.translatesAutoresizingMaskIntoConstraints = false
        notifications.setTitle("Notifications", for: .normal)
        notifications.setTitleColor(.blue, for: .normal)
        //notifications.addTarget(self, action: #selector(pushNavViewController), for: .touchUpInside)
        view.addSubview(notifications)*/
        
        /*
        addFriend = UIButton()
        addFriend.translatesAutoresizingMaskIntoConstraints = false
        addFriend.setTitle("Add Friend", for: .normal)
        addFriend.setTitleColor(.red, for: .normal)
        //notifications.addTarget(self, action: #selector(pushNavViewController), for: .touchUpInside)
        view.addSubview(addFriend)*/
        
        setupConstraints()
    
    }
    
    func setupConstraints() {
        // Setup the constraints for our views
        NSLayoutConstraint.activate([
            stockView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            stockView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            stockView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),
            stockView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
            ])
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = stockView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! StockTableViewCell
        let stock = stocks[indexPath.row]
        cell.configure(for: stock)
        cell.setNeedsUpdateConstraints()
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return stocks.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let stockViewController = StockScreenViewController()
        stockViewController.delegate = self
        stockViewController = indexPath.row
        self.navigationController?.pushViewController(stockViewController, animated: true)
        
        
    }
    
    @objc func notificationsButtonTapped() {
        print("notifications tapped")
    }
    
    @objc func addFriendButtonTapped() {
        print("friends tapped")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
